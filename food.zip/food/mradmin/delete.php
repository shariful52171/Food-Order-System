<?php 
	include_once('include/conn.php');
	include_once('include/functions.php');
	session_start();
	if(isset($_SESSION['username'])){
		if(isset($_GET['idd'])){
		//$delid = $_GET['idd'];
		$sql = "DELETE FROM `orders` WHERE id='".$_GET['idd']."'";
		$sql = mysqli_query($conn, $sql);
		if($sql){
			echo "<script>window.open('index.php?deleted=user has been deleted','_self')</script>";
		}else{
			echo mysqli_error();
		}
	}
}
?>