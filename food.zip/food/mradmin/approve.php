<?php
	include 'includs/head.php';
	include 'includs/header.php';
print_r($_GET);
	if($_SESSION['username']){
		if(isset($_GET['id']) && $_GET['approved'] == 1){
			
			$id = mysqli_real_escape_string($db, htmlentities(htmlspecialchars($_GET['id'])));
			
			$sq = "UPDATE `orders` SET `aproval` = '1' WHERE `id` = '$id'";
				if(mysqli_query($db, $sq)){
					header('Location:admin.php?order');
				}else{
					echo 'error';
				}
			
		}else if(isset($_GET['id']) && $_GET['ap'] == 2){
			$id = mysqli_real_escape_string($db, htmlentities(htmlspecialchars($_GET['id'])));
			
			$sq = "UPDATE `orders` SET `aproval` = '2' WHERE `id` = '$id'";
				if(mysqli_query($db, $sq)){
					header('Location:admin.php?order');
				}else{
					echo 'error';
				}
		}else if(isset($_GET['id']) && $_GET['ap'] == 3){
			$id = mysqli_real_escape_string($db, htmlentities(htmlspecialchars($_GET['id'])));
			
			$sq = "UPDATE `orders` SET `aproval` = '3' WHERE `id` = '$id'";
				if(mysqli_query($db, $sq)){
					header('Location:admin.php?order');
				}else{
					echo 'error';
				}
		}else{
			header('Location:admin.php?orders=1');
		}
	}else{
		header('Location:index.php');
	}
	
include 'includs/footer.php';
?>