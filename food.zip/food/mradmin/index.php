<?php
	include_once('include/header.php');
	$page = $_SERVER['PHP_SELF'];
	$sec = "300";
	
	if(isset($_SESSION['username'])){
?>
<section class="log-out-area">
	<div class="container">
		<div class="logout-box">
			<a href="logout.php">LogOut</a>
		</div>
	</div>
</section>
<section class="form-to-date-area">
	<div class="container">
		<div class="get-date-box">
			<form method="post" action="index.php">
			<input type="text" placeholder="From Date" id="datepicker" name="from_date" />
				
				<input type="text" placeholder="To Date" id="todatepicker" name="to_date" style="margin-left:10px" />	
				
				<input type="submit" value="Search" >
			</form>
		</div>
	</div>
</section>
<section class="view_box">
	<div class="container">
		<div class="viewtable table-responsive">
			<table class="table table-striped">
				<tr>
					<th class="viewtext">Date</th>
					<th class="viewtext">Name</th>
					<th class="viewtext">Role</th>
					<th class="viewtext">Phone</th>
					<th class="viewtext">Address</th>
					<th class="viewtext">Box Type</th>
					<th class="viewtext">Qnty.</th>
					<th class="viewtext">Price</th>
					<th class="viewtext">Pmnt. Type</th>
					<th class="viewtext">bkash NO.</th>
					<th class="viewtext">Trans. ID</th>
					<th class="viewtext">Total</th>
					<th class="viewtext">Approved</th>
					<th class="viewtext">Delete</th>
				</tr>
				<?php
					// view data
					$sql ="SELECT * FROM `orders` ORDER BY `date` DESC LIMIT 100";
					$sql = mysqli_query($conn, $sql);
					while($row = mysqli_fetch_array($sql)){
						$date = $row['date'];
						$name = $row['name'];
						$phone = $row['phone'];
						$address = $row['address'];
						$foodname = $row['foodname'];
						$qnty = $row['quantity'];
						$price = $row['price'];
						$role = $row['designation'];
						$bkash = $row['bkashnumber'];
						$trans = $row['transid'];
						$payment = $row['paymenttype'];
						$total = $row['total'];
						$approve = $row['approved'];
						$user_id = $row['id'];
						?>
						<tr>
							<td><?php echo $date;?></td>
							<td><?php echo $name;?></td>
							<td><?php echo $role;?></td>
							<td><?php echo $phone;?></td>
							<td><?php echo $address;?></td>
							<td><?php echo $foodname;?></td>
							<td><?php echo $qnty;?></td>
							<td><?php echo $price;?></td>
							<td><?php echo $payment;?></td>
							<td><?php echo $bkash;?></td>
							<td><?php echo $trans;?></td>
							<td><?php echo $total;?></td>
							<td><a href=''><?php echo $approve;?></a></td>
							<td><a class='delete-btn' href='delete.php?idd=<?php echo $user_id;?>'>Delete</a></td>
						</tr>
				<?php
					}			
					$add = "SELECT SUM(total) FROM `orders`";
					$add = mysqli_query($conn, $add);
					while($row1 = mysqli_fetch_array($add)){
					$grand_total = $row1['SUM(total)'];
						?>
						<tr>
							<td colspan="10"></td>
							<td><strong>Total</strong></td>
							<td colspan="3" style='text-align:center; font-weight:bold;'><?php echo $grand_total;?> <span class="tk">TK</span></td>
						</tr>
					<?php
					}
					mysqli_close($conn);
				?>
			</table>
		</div>
	</div>
</section>


<?php
}else{
	 echo "<script>window.open('login.php','_self')</script>"; 
}
include_once('include/footer.php');
?>