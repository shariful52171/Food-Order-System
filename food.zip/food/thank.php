<?php
	include_once('include/header.php');
?>
<section class="thankyou-area">
	<div class="container">
		<div class="success-box">
			<h2>Order Successful</h2>
			<p>We will contact with you. Please keep switch on your Phone</p>
			<div class="suc-sign">
				<img src="img/suc.png" alt="">
			</div>
		</div>
	</div>
</section>
<?php
include_once('include/footer.php');
?>	