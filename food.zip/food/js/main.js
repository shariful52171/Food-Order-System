$(document).ready(function(){
	
		/* menu show and hide*/
		
    new WOW().init();
    $('.up').on('click', function(){
			var $qty = $(this).closest('.price-box').find('.qnty');
			var currentVal = parseInt($qty.val());
			if(!isNaN(currentVal)){
				$qty.val(currentVal + 1);
			}
		});
		$('.down').on('click', function(){
			var $qty = $(this).closest('.price-box').find('.qnty');
			var currentVal = parseInt($qty.val());
			if(!isNaN(currentVal) && currentVal > 0){
				$qty.val(currentVal -1);
			}
		});	
	
		/* hide and show after select field*/
		$('#paymenttype').change(function(){
		   selection = $(this).val();    
		   switch(selection)
		   { 
			   case 'bkash':
				   $('#bkashSec').show();
				   break;
			   default:
				   $('#bkashSec').hide();
				   break;
		   }
		});
		$('#orderForm').change(function(){
		   selection = $(this).val();    
		   switch(selection)
		   { 
			   case 'executive':
				   $('#price-1').show();
				   break;
			   default:
				   $('#price-1').hide();
				   break;
		   }
		});
		$('#orderForm').change(function(){
		   selection = $(this).val();    
		   switch(selection)
		   { 
			   case 'premium':
					$('#price-2').show();
					break;
				default:
					$('#price-2').hide();
					break;
		   }
		});
		$('#orderForm').change(function(){
		   selection = $(this).val();    
		   switch(selection)
		   { 
			   case 'exclusive':
					$('#price-3').show();
					break;
				default:
					$('#price-3').hide();
					break;
		   }
		});
		
		$(".stick-box").sticky({
			topSpacing:0,
			bottomSpacing:550
		});
		$(".sticky-first").sticky({
			topSpacing:15,
			bottomSpacing:550
		});
});
