<?php

	$conn = mysqli_connect('localhost', 'root', '', 'phptut');
	//$conn = mysqli_connect('localhost', 'mrfoodco_orders', 'bbamgt$161', 'mrfoodco_mrfood');
	if(!$conn){
		die("Connection Faild:" . mysqli_connect_error());
	}
?>