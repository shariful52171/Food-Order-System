<?php
	function destroytag($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	
	function loggedin(){
	if(isset($_SESSION['userid'])){
		return true;
	}else{
		return false;
	}
}

?>