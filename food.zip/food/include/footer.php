<section class="icon_box_area">
		  	<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="icon_box">
							<div class="single_icon">
								<i class="fa fa-mobile"></i>
								<h2>Mobile</h2>
							</div>
							<div class="single_icon">
								<i class="fa fa-comment"></i>
								<h2>Message Us</h2>
							</div>	
							<div class="single_icon">
								<i class="fa fa-user"></i>
								<h2>About Us</h2>
							</div>
							<div class="single_icon">
								<i class="fa fa-envelope"></i>
								<h2>Contact Us</h2>
							</div>
							<div class="single_icon">
								<i class="fa fa-list-alt"></i>
								<h2>Blog</h2>
							</div>	
							<div class="single_icon">
								<i class="fa fa-twitter"></i>
								<h2>Twitter</h2>
							</div>	
							<div class="single_icon">
								<i class="fa fa-instagram"></i>
								<h2>Instagram</h2>
							</div>	
							<div class="single_icon">
								<i class="fa fa-users"></i>
								<h2>Career</h2>
							</div>	
							<div class="single_icon">
								<i class="fa fa-briefcase"></i>
								<h2>Corporate</h2>
							</div>	
							<div class="single_icon">
								<i class="fa fa-cutlery"></i>
								<h2>Restaurant Owner</h2>
							</div>		
						</div>
					</div>
				</div>
		 	</div>
		</section>

		<section class="payment-area">
			<div class="container">
				<div class="row">
					<div class="payment-icon-row">
						<p>We support the following payment methods</p>
						<ul>
							<li><img src="img/payment-1.png" alt="" /></li>
							<li><img src="img/payment-2.png" alt="" /></li>
						</ul>
					</div>
				</div>
			</div>	
		</section>

		<footer class="footer_area">
			<div class="container footer">
				<div class="row">
					<div class="col-md-12">
						<div class="social">
							<a href="https://www.facebook.com/mrfoodbd" target="_blank" class="btn social-icon"><i class="fa fa-facebook"></i></a>
							<a href="#" class="btn social-icon"><i class="fa fa-twitter"></i></a>
							<a href="#" class="btn social-icon"><i class="fa fa-tumblr"></i></a>
							<a href="#" class="btn social-icon"><i class="fa fa-google-plus"></i></a>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<p><b>Cuisines:</b> Pizza | Chinese | Indian | Thai | Sushi | All Cuisines<br>
						View Privacy Statement | By using our site you agree to our terms of use.<br>
						Feeding the internet 24 hours © 2015 mrfood.com.bd - Food Delivery</p>
					</div>  	
				</div>	
			</div>	
		</footer>

        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery.min.js"><\/script>')</script>
        <script src="js/bootstrap.min.js"></script>
		<script src="js/wow.js"></script>
		<script src="js/pop.js"></script>
		<script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
    </body>
</html>