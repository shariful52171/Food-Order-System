<?php
include_once('include/conn.php');
include_once('include/functions.php');
session_start();
if(isset($_POST['login'])){  
    $phone = $_POST['user_phone'];  
    $password = $_POST['password'];  
	if(!empty($_POST['user_phone']) && !empty($_POST['password'])){
		$phone1 = mysqli_real_escape_string($conn, $phone);
		$password1 = mysqli_real_escape_string($conn, $password);
		$check_user="select * from userlogin WHERE phone='$phone1'AND password='$password1'";  
  
		$run=mysqli_query($conn,$check_user);  
  
		if(mysqli_num_rows($run)){  
			echo "<script>window.open('index.php','_self')</script>";  
	  
			$_SESSION['phone']=$phone;//here session is used and value of $user_email store in $_SESSION.  
	  
		}else{
			echo "<script>popup('phone or password is incorrect!')</script>";
		} 
	}  
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
		<link rel="shortcut icon" href="img/fav.png" type="image/x-png">
		<link rel="icon" href="img/fav.png" type="image/x-png">
        <title>MR.FOOD-HYGIENIC FOOD DELIVERY SERVICE IN BANGLADESH</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- Google fonts - witch you want to use - (rest you can just remove) -->
	   	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
	    <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	   
        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <link rel="stylesheet" href="css/star-rating.css">
        <link rel="stylesheet" href="css/animate.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/normalize.css">
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="css/main.css">
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="css/responsive.css">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <!-- Add your site or application content here -->
<!-- pop up -->	
<section class="sponsor-area">
	<div class="container">
		<div class="sponsor-box">
			<div class="shop-menu">
				<div class="shop-nav">
					<div class="nav-text"><i class="fa fa-bars" aria-hidden="true"></i></div>
					<div class="nav-text e-text">e-food Shop</div>
					<!--dropdown menu start
						<div class="nav-hide-menu">
							<ul>
								<li class="e-row"><span class="e-food">e</span>-food Shop</li>
								<li><a href="">Fruits & vegetables</a>
								
									<div class="inner-menu">
										<ul>
											<li><a href="">Menu 1</a></li>
											<li><a href="">Menu 1</a></li>
											<li><a href="">Menu 1</a></li>
											<li><a href="">Menu 1</a></li>
											<li><a href="">Menu 1</a></li>
											<li><a href="">Menu 1</a></li>
											<li><a href="">Menu 1</a></li>
										</ul>
									</div>
								</li>
								<li><a href="">Grocery & Staples</a></li>
								<li><a href="">Bread Dairy & Eggs</a></li>
								<li><a href="">Beverages</a></li>
								<li><a href="">Branded food</a></li>
								<li><a href="">Personal Care</a></li>
								<li><a href="">Household</a></li>
							</ul>
						</div>-->
					<!--dropdown menu end-->
				</div>
			</div>
			<div class="left-sponsor">
				<ul>
					<li class="sp-text">In partnership with:</li>
					<li><a href=""><img src="img/sp1.png" alt="" /></a></li>
					<li><a href=""><img src="img/sp2.png" alt="" /></a></li>
					<li><a href=""><img src="img/sp3.png" alt="" /></a></li>
					<li><a href=""><img src="img/sp4.png" alt="" /></a></li>
					<li><a href=""><img src="img/sp5.png" alt="" /></a></li>
					<li><a href=""><img src="img/sp6.png" alt="" /></a></li>
				</ul>
			</div>
		</div>
	</div>
</section>
        <header class="headar_area">
			<div class="container">
				<div class="row">
					<div class="header-box">
						<div class="col-md-4">
							<div class="col-md-6">
								<div class="logo">
									<a href="index.php"><img src="img/logo.png"></a>
								</div>
							</div>
							<div class="col-md-6">
								<div class="logo-right">
									<h2 class="wow fadeInRight" data-wow-delay="300ms">Just Order</h2>
									<h3 class="wow fadeInRight" data-wow-delay="600ms">Fast Deliver</h3>
								</div>
							</div>
						</div>
						<div class="slogan-box">
							<img src="img/slogan.png" alt="" />
						</div>
						<div class="login-area">
							<div class="login-box">
								<ul>
								<?php 
									if(!isset($_SESSION['phone'])){
										echo "<li data-toggle='modal' data-target='#myModal'><i class='fa fa-user' aria-hidden='true'></i> log <span class='bold-text'
										'>in</span></li>";
									}else{
										echo "<li><a href='logout.php'><i class='fa fa-sign-out' aria-hidden='true'></i> log <span class='bold-text'
										'>out</span></a></li>";
									}
								?>
									<!-- Modal -->
								<div id="myModal" class="modal fade" role="dialog">
								  <div class="modal-dialog">

									<!-- Modal content-->
									<div class="modal-content">
									  <div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
									  </div>
									  <div class="modal-body">
										<div class="login-text">
											<h2>Login</h2>
											<p>If you were hungry enough to register to our website before, you can login here</p>
										</div>
										<div class="login-form-area">
											<form name="loginform" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" onsubmit="return validateForm()">
												<div class="login-input-group">
													<input type="text" name="user_phone" class="login-form-feild loginphone" placeholder="Mobile Number"/>
													<span id="error"></span>
												</div>
												<input type="password" name="password" class="login-form-feild loginpass" placeholder="Your Password"/>
												<button name="login" class="login-savbtn">Login Now</button>
											</form>
										</div>
										<div class="forgot-pass">
											Forgot password? It's ok. <a class="reset-pw" href="">Reset password</a>
										</div>
										<div class="fblogin-area">
											<button class="smlogin fblogin">
												<i class="fa fa-facebook"></i>
												 Login/Register with Facebook
											</button>
											<button class="smlogin gplogin">
												<i class="fa fa-google-plus"></i>
												 Login/Register with GooglePlus
											</button>
										</div>
									  </div>
									</div>

								  </div>
								</div>
								
								<?php
									if(!isset($_SESSION['phone'])){
										echo"<li class='model2' data-toggle='modal' data-target='#myModal2'><i class='fa fa-sign-in' aria-hidden='true'></i> sign <span class='bold-text'>up</span></li>";
									}else{
										echo"<li style='display:none;' class='model2' data-toggle='modal' data-target='#myModal2'><i class='fa fa-sign-in' aria-hidden='true'></i> sign <span class='bold-text'>up</span></li>";
									}
								?>
									
									
									 <!-- Modal -->
								<div id="myModal2" class="modal fade" role="dialog">
									<div class="modal-dialog">

										<!-- Modal content-->
										<div class="modal-content">
										  <div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">&times;</button>
										  </div>
										  <div class="modal-body">
											 <div class="modal-reg-form">
												<div class="login-text">
													<h2>Sign Up</h2>
													<p>Sign up using your Email address</p>
												</div>
												<form name="reg-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
													<input type="text" name="name" class="login-form-feild nameman" placeholder="Enter Your Name"/>
													
													<input type="email" name="email" class="login-form-feild loginemail" placeholder="Your Email"/>
													
													<input type="password" name="password" class="login-form-feild loginpass" placeholder="Your Password"/>
													
													<input type="password" name="passwordcon" class="login-form-feild loginpass" placeholder="Confirm Password"/>
													 <p class="active-number">Your Active Mobile Number</p>
													 <input type="text" name="user_phone" class="login-form-feild phonebg" placeholder="eg. 01757-XXXXXX"/>
													
													<button name="register" class="login-savbtn">Create My Account</button>
												</form>
												<div class="text-sign">
													<p>Oh you remember you signed up earlier?</br>
													Thats nice, go ahead and login</p>
												 </div>
											</div>
										  </div>
										</div>
									</div>
								</div>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>		
        </header>
<?php
if(isset($_POST['register'])){
	$username = $_POST['name'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$passwordcon = $_POST['passwordcon'];
	$phone = $_POST['user_phone'];
	if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['password']) && !empty($_POST['passwordcon']) && !empty($_POST['user_phone'])){
		$user = mysqli_real_escape_string($conn, $username);
		$user_mail = mysqli_real_escape_string($conn, $email);
		$pass = mysqli_real_escape_string($conn, $password);
		$pass_con = mysqli_real_escape_string($conn, $passwordcon);
		$number = mysqli_real_escape_string($conn, $phone);
		//here query check weather if user already registered so can't register again.  
		$check_phone_query = "select * from `userlogin` WHERE `email` = '$user_mail' AND `phone` = '$number'";  
		$run_query = mysqli_query($conn, $check_phone_query);  
	  
		if(mysqli_num_rows($run_query)>0){  
			echo "<script>alert('phone number $number is already exist in our database, Please try another one!')</script>";  
			exit();  
		}  
		
	//insert the user into the database.  
		$insert_user="INSERT INTO `userlogin` (`user_id`,`name`,`email`,`password`,`phone`) VALUE ('','$user','$user_mail','$pass','$number')";  
		if(mysqli_query($conn, $insert_user)){  
			echo"<script>window.open('index.php','_self')</script>";  
		}
	}
}
?>
<script type="text/javascript">
	function validateForm() {
    var x = document.forms["loginform"]["user_phone"].value;
    if (x == null || x == "") {
		document.getElementById('error').innerHTML = "Phone number required";
        return false;
    }
}
</script>