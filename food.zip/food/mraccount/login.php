<?php
include_once('include/conn.php');
include_once('include/functions.php');
include_once('include/header.php');
error_reporting(E_ALL ^ E_NOTICE);
session_start();
if(isset($_POST['login'])){
	$username = $_POST['username'];
	$pass = $_POST['password'];
	if(!empty($_POST['username']) && !empty($_POST['password'])){
		$username1 = mysqli_real_escape_string($conn, $username);
		$pass1 = mysqli_real_escape_string($conn, $pass);
		$sql ="SELECT * FROM `adminuser` WHERE `username` = '$username1' AND `password` = '$pass1'";
		$user_check = mysqli_query($conn, $sql);
		if(mysqli_num_rows($user_check)){
			 echo "<script>window.open('index.php','_self')</script>";  
  
        $_SESSION['username']=$username1;//here session is used and value of $user_email store in $_SESSION. 
		}else{
			echo "<script>alert('invaid username')</script>";
		}
	}
}
?>
<section class="admin-login-area">
	<div class="container">
		<div class="row">
			<div class="admin-login-box">
				<div class="admin-login-head">
					<h3>Login Here</h3>
				</div>
				<form action="" method="post">
					<div class="admin-field-box">
						<p>Username</p>
						<input class="admin-field" type="text" name="username" required/>
					</div>
					<div class="admin-field-box">
						<p>Password</p>
						<input class="admin-field" type="password" name="password" required/>
					</div>
					<div class="login-btn-box">
						<input class="admin-btn" type="submit" name="login" value="Login" />
					</div>
				</form>
			</div>
		</div>
	</div>
</section>
<?php
include_once('include/footer.php');
?>