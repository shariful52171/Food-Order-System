<?php
	include_once('include/conn.php');
	include_once('include/functions.php');
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
		<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
		<link rel="icon" href="img/favicon.ico" type="image/x-icon">
        <title>MR.FOOD-HYGIENIC FOOD DELIVERY SERVICE IN BANGLADESH</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- Google fonts - witch you want to use - (rest you can just remove) -->
	   	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
	    <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	   
        <link rel="stylesheet" href="css/animate.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/jqueryui.css">
		<link rel="stylesheet" href="css/normalize.css">
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="css/style.css">
        <script src="js/modernizr-2.6.2.min.js"></script>
    </head>
<body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <!-- Add your site or application content here -->
<section class="food-header-area">
	<div class="container">
		<div class="food-header-box">
			<p class="text-head">Mr.Food & Beverage</p>
			<p>Hyperian Shopi Shams,Chanmari Road,Lalkahn bazaar,Chittagong </br>Cell : 031-617271,01959886650, 01959886651</p>
			<p class="daily-sheet">Daily Food Delivery Sheet</p>
		</div>
	</div>
</section>
<section class="soft-menu">
	<div class="container">
		<div class="soft-menu-bar">
			<ul>
				<li><a href="index.php">Add Record</a></li>
				<li><a href="" id="print" onclick="myFunction()">Print</a></li>
				<li><a href="view.php">view all Records</a></li>
				<li><a href="logout.php">logout</a></li>
				<script>
					function myFunction() {
						window.print();
					}
				</script>
			</ul>
		</div>
	</div>
</section>