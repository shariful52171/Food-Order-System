
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/jquery.min.js"><\/script>')</script>
        <script src="js/bootstrap.min.js"></script>
		<script src="js/jqueryui.js"></script>
		<script src="js/wow.js"></script>
        <script src="js/main.js"></script>
    </body>
</html>