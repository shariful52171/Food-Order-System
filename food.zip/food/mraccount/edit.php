<?php
	include_once('include/header.php');		
if(isset($_GET['ide'])){
	if(isset($_POST['update'])){
	$sql ="UPDATE adminreport SET
					name='".$_POST['newpname']."',
					role='".$_POST['newprole']."',
					institution='".$_POST['newins']."',
					address='".$_POST['newaddress']."',
					payment='".$_POST['newpmnt']."',
					box_type='".$_POST['newboxtype']."',
					price='".$_POST['newprice']."',
					qnty='".$_POST['newqnty']."',
					discount='".$_POST['newdiscount']."',
					paid='".$_POST['newpaid']."',
					ref_name='".$_POST['newref']."',
					ref_taka='".$_POST['newref_taka']."',
					ref_paid='".$_POST['newref_paid']."',
					pmnt_date='".$_POST['newpmnt_date']."'
					WHERE p_id='".$_GET['ide']."'";
	$res = mysqli_query($conn, $sql);
			if($res){
				echo "<script>window.open('view.php?updated=report data has been updated','_self')</script>";
			}else{
				echo mysqli_error($conn);
			}
		}
	}
?>
<section class="account-section">
	<div class="container">
		<div class="mrfood-box-top">
			<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post">
				<div class="col-md-6">
					<div class="order-box">
						<table class="table table-reponsive newtable">
							<tr>
								<div class="grp-form">
									<td>Order Person:</td>
									<td><input type="text" name="newpname" class="input-feild" value="<?php echo $name;?>" /></td>
								</div>
							</tr>
							<tr>
								<div class="grp-form">
									<td>Designation:</td>
									<td><input type="text" name="newprole" class="input-feild" value="<?php echo $role;?>" /></td>
								</div>
							</tr>
							<tr>
								<div class="grp-form">
									<td>Institution Name:</td>
									<td><input type="text" name="newins" class="input-feild" value="<?php echo $inst;?>"/></td>
								</div>
							</tr>
							<tr>
								<div class="grp-form">
									<td>Address:</td>
									<td><input type="text" name="newaddress" class="input-feild" value="<?php echo $address;?>" /></td>
								</div>
							</tr>
							<tr>
								<div class="grp-form">
									<td>Payment Type:</td>
									<td>
										<select name="newpmnt" id="" class="input-feild" >
											<option value="default">Payment Type</option>
											<option value="weekly">Weekly</option>
											<option value="daily">Daily</option>
											<option value="monthly">Monthly</option>
										</select>
									</td>
								</div>
							</tr>
						</table>
					</div>
				</div>
				<div class="col-md-6">
					<div class="refer-box">
						<table class="table table-reponsive">
							<tr>
								<div class="grp-form">
									<td>Date:</td>
									<td><input type="text" name="newdate" class="input-feild" value="<?php echo date("d-m-y");?>" /></td>
								</div>
							</tr>
							<tr>
								<div class="grp-form">
									<td>Refference Name:</td>
									<td><input type="text" name="newref" class="input-feild" value="<?php echo $ref;?>" /></td>
								</div>
							</tr>
						</table>
					</div>
				</div>
			</div>
		</div>
</section>
<section class="account-section-2">
	<div class="container-fulid">
		<div class="mrfood-report-box">
			<table class="table table-reponsive report-table">
				<tr>
					<th>Box Type</th>
					<th>Price</th>
					<th>NO. of Order</th>
					<th>Discount</th>
					<th>Paid</th>
					<th>Ref. Taka</th>
					<th>Paid</th>
					<th>Pmnt. Date</th>
					<th>Remarks</th>
				</tr>
				<tr>
					<td>
						<select name="newboxtype"  class="food-field" id="boxtype">
							<option value="default">select</option>
							<option value="executive">Executive</option>
							<option value="premium">Premium</option>
							<option value="exclusive">Exclusive</option>
						</select>
					</td>
					<td>
						<select name="newprice"  class="food-field" id="price">
							<option value="default">select</option>
							<option value="65">65 TK</option>
							<option value="85">85 TK</option>
							<option value="100">100 TK</option>
						</select>
					</td>
					<td><input type="text" name="newqnty" id="qnty" class="food-field" value="<?php echo $qnty;?>"/></td>
					<td><input type="text" name="newdiscount" id="discount" class="food-field" value="<?php echo $discount;?>"/></td>
					<td><input type="text" name="newpaid" id="paid" class="food-field" value="<?php echo $paid;?>"/></td>
					<td><input type="text" name="newref_taka" id="ref_taka" class="food-field" value="<?php echo $ref_taka;?>"/></td>
					<td><input type="text" name="newref_paid" id="ref_paid" class="food-field" value="<?php echo $ref_paid;?>"/></td>
					<td><input type="text" id="datepicker" name="newpmnt_date" class="food-field" value="<?php echo $pmnt_date;?>"/></td>
					<input type="hidden" name="id" value="<?php echo $_GET['ide'];?>"/>
					<td><input type="submit" name="update" class="add-btn" id="save" value="Update"/></td>
				</tr>
			</form>
			</table>
		</div>
	</div>
</section>
<?php
	

?>
<?php
	include_once('include/footer.php');
?>