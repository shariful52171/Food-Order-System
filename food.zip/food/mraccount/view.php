<?php
	include_once('include/header.php');
	session_start();
?>
<section class="searh-area">
	<div class="container">
		<div class="serach-field">
		<?php
			$fdate="";
			$tdate="";
			if(isset($_POST['fdate']) && isset($_POST['tdate'])){
				if(!empty($_POST['fdate']) && !empty($_POST['tdate'])){
					$fdate = htmlspecialchars(htmlentities($_POST['fdate']));
					$tdate = htmlspecialchars(htmlentities($_POST['tdate']));
					header('Location:search.php?fdate='.$fdate.' && tdate='.$tdate.'');
				}
			}
		?>
			<form action="view.php" method="post">
				<input type="text" name="fdate" class="fdate" id="datepicker" placeholder="From Date"/>
				<input type="text" name="tdate" class="fdate" id="todatepicker" placeholder="To Date" />
				<input type="submit" name="search" class="save-btn" value="search"/>
			</form>
		</div>
	</div>
</section>
<section class="account-section-2">
	<div class="container-fulid">
		<div class="mrfood-report-box">
			<table class="table table-reponsive report-table">
				<tr>
					<th>Date</th>
					<th>Order Person</th>
					<th>Designation</th>
					<th>Inst.</th>
					<th>Address</th>
					<th>Box Type</th>
					<th>Pmnt. Type</th>
					<th>Price</th>
					<th>qnty.</th>
					<th>Discount</th>
					<th>Gross Total</th>
					<th>Paid</th>
					<th>Due</th>
					<th>Ref. Name</th>
					<th>Ref. Taka</th>
					<th>Paid</th>
					<th>Due</th>
					<th>Net Total</th>
					<th>Pmnt. Date</th>
					<th>Remarks</th>
					<th>Edit</th>
				</tr>
			<?php
				$search ="SELECT * FROM `adminreport` ORDER BY `p_id` DESC LIMIT 25";
				$search_record = mysqli_query($conn, $search);
				while($row = mysqli_fetch_array($search_record)){
					$id				=	$row['p_id'];
					$date			=	$row['date'];
					$name			=	$row['name'];
					$role			=	$row['role'];
					$ins			=	$row['institution'];
					$address		=	$row['address'];
					$boxtype		=	$row['box_type'];
					$pmnt_type		=	$row['payment'];
					$price			=	$row['price'];
					$qnty			=	$row['qnty'];
					$discount		=	$row['discount'];
					$gross			=	$row['gross_total'];
					$paid			=	$row['paid'];
					$due			=	$row['due'];
					$ref_name		=	$row['ref_name'];
					$ref_taka		=	$row['ref_taka'];
					$ref_paid		=	$row['ref_paid'];
					$ref_due		=	$row['ref_due'];
					$net			=	$row['net_total'];
					$pmnt_date		=	$row['pmnt_date'];
					$remarks		=	$row['remarks'];
					?>
					<tr>
						<td align="center"><?php echo $date;?></td>
						<td align="center"><?php echo $name;?></td>
						<td align="center"><?php echo $role;?></td>
						<td align="center"><?php echo $ins;?></td>
						<td align="center"><?php echo $address;?></td>
						<td align="center"><?php echo $boxtype;?></td>
						<td align="center"><?php echo $pmnt_type;?></td>
						<td align="center"><?php echo $price;?></td>
						<td align="center"><?php echo $qnty;?></td>
						<td align="center"><?php echo $discount;?></td>
						<td align="center"><?php echo $gross;?></td>
						<td align="center"><?php echo $paid;?></td>
						<td align="center"><?php echo $due;?></td>
						<td align="center"><?php echo $ref_name;?></td>
						<td align="center"><?php echo $ref_taka;?></td>
						<td align="center"><?php echo $ref_paid;?></td>
						<td align="center"><?php echo $ref_due;?></td>
						<td align="center"><?php echo $net;?></td>
						<td align="center"><?php echo $pmnt_date;?></td>
						<td align="center"><?php echo $remarks;?></td>
						<td align="center"><a class="edit-btn" href='index.php?ide=<?php echo $id?>'>edit</a></br><a class="edit-btn" href='delete.php?ide=<?php echo $id?>'>Del</a></td>
					</tr>
				<?php
				}
				$add ="SELECT SUM(paid), SUM(due),SUM(net_total) FROM `adminreport`";
				$query = mysqli_query($conn, $add);
				while($row = mysqli_fetch_array($query)){
					$paidtotal = $row['SUM(paid)'];
					$duetotal = $row['SUM(due)'];
					$nettotal = $row['SUM(net_total)'];
					?>
					<tr>
						<td colspan="7"></td>
						<td class="report-bold" colspan="2">Total Paid</td>
						<td class="report-bold report-nu" colspan="2"><?php echo $paidtotal;?> <span>TK</span></td>
						<td class="report-bold report-nu" colspan="2"><?php echo $duetotal;?> <span>TK</span></td>
						<td class="report-bold" colspan="3">Net Total</td>
						<td class="report-bold report-nu" colspan="4"><?php echo $nettotal;?> <span>TK</span></td>
					</tr>
					<?php
				}
				mysqli_close($conn);
			?>
			</table>
		</div>
	</div>
</section>
<?php
	include_once('include/footer.php');
?>