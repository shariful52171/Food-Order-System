<?php
	session_start();
	include_once('include/header.php');
if(isset($_SESSION['username'])){
	$name=$role=$inst=$address=$payment=$date=$reference=$boxtype=$price=$qnty=$discount=$gross=$paid="";
	$ref_taka=$ref_paid=$ref_due=$net=$pmnt_date=$due="";
	if(isset($_GET['ide'])){
		$sql ="SELECT * FROM `adminreport` WHERE `p_id`='".$_GET['ide']."'";
		$result =mysqli_query($conn, $sql);
		while($row = mysqli_fetch_array($result)){
			$name = $row['name'];
			$role = $row['role'];
			$inst = $row['institution'];
			$address = $row['address'];
			$reference = $row['ref_name'];
			$qnty = $row['qnty'];
			$discount = $row['discount'];
			$paid = $row['paid'];
			$gross = $row['gross_total'];
			$ref_taka = $row['ref_taka'];
			$ref_paid = $row['ref_paid'];
			$ref_due = $row['ref_due'];
			$pmnt_date = $row['pmnt_date'];
			$net = $row['net_total'];
			$due = $row['due'];
			$price = $row['price'];
		}
	}
	if(isset($_POST['save'])){
		$name			=	mysqli_real_escape_string($conn, $_POST['pname']);
		$role			=	mysqli_real_escape_string($conn, $_POST['prole']);
		$inst			=	mysqli_real_escape_string($conn, $_POST['ins']);
		$address		=	mysqli_real_escape_string($conn, $_POST['address']);
		$payment		=	mysqli_real_escape_string($conn, $_POST['pmnt']);
		$date			=	mysqli_real_escape_string($conn, date('d-m-Y', time()));
		$reference		=	mysqli_real_escape_string($conn, $_POST['ref']);
		$boxtype		=	mysqli_real_escape_string($conn, $_POST['boxtype']);
		$price			=	mysqli_real_escape_string($conn, $_POST['price']);
		$qnty			=	mysqli_real_escape_string($conn, $_POST['qnty']);
		$discount		=	mysqli_real_escape_string($conn, $_POST['discount']);
		$gross			=	mysqli_real_escape_string($conn, ($price*$qnty)-$discount);
		$paid			=	mysqli_real_escape_string($conn, $_POST['paid']);
		$ref_taka		=	mysqli_real_escape_string($conn, $_POST['ref_taka']);
		$ref_paid		=	mysqli_real_escape_string($conn, $_POST['ref_paid']);
		$ref_due		=	mysqli_real_escape_string($conn, $ref_taka-$ref_paid);
		$net			=	mysqli_real_escape_string($conn, $gross-$ref_taka);
		$pmnt_date		=	mysqli_real_escape_string($conn, $_POST['pmnt_date']);
		$due			=	mysqli_real_escape_string($conn, $net-$paid);
		if(isset($_POST['edit'])){
			$ide = $_POST['edit'];
			$sql = "UPDATE `adminreport` SET `name`='$name',`role`='$role',`institution`='$inst',`address`='$address',`payment`='$payment',`box_type`='$boxtype' WHERE `p_id`='$ide'";
			if(mysqli_query($conn, $sql)){
				echo"<meta http-equiv='refresh' content='0; url=view.php?Data=Updated'/>";
			}else{
				die("Not Updated");
			}
		}else{
			$sql ="INSERT INTO `adminreport`(`p_id`, `date`, `name`, `role`, `institution`, `address`,`payment`, `box_type`, `price`, `qnty`, `discount`, `gross_total`, `paid`, `due`, `ref_name`, `ref_taka`, `ref_paid`, `ref_due`, `net_total`, `pmnt_date`) VALUES ('','$date','$name','$role','$inst','$address','$payment','$boxtype','$price','$qnty','$discount','$gross','$paid','$due','$reference','$ref_taka','$ref_paid','$ref_due','$net','$pmnt_date')";
			
			if(mysqli_query($conn, $sql)){
				echo"<script>self.location =index.php?msg=data added</script>";
			}else{
				die("Data Not Added!");
			}	
		}
	}

?>
<section class="account-section">
	<div class="container">
		<div class="mrfood-box-top">
			<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post">
				<?php
					if(isset($_GET['ide'])){
				?>
					<input type="hidden" name="edit" value="<?php echo $_GET['ide'];?>" />	
				<?php
					}
				?>
				<div class="col-md-6">
					<div class="order-box">
						<table class="table table-reponsive newtable">
							<tr>
								<div class="grp-form">
									<td>Order Person:</td>
									<td><input type="text" name="pname" class="input-feild" value="<?php echo $name;?>" required/></td>
								</div>
							</tr>
							<tr>
								<div class="grp-form">
									<td>Designation:</td>
									<td><input type="text" name="prole" class="input-feild" value="<?php echo $role;?>" required/></td>
								</div>
							</tr>
							<tr>
								<div class="grp-form">
									<td>Institution Name:</td>
									<td><input type="text" name="ins" class="input-feild" value="<?php echo $inst;?>" required/></td>
								</div>
							</tr>
							<tr>
								<div class="grp-form">
									<td>Address:</td>
									<td><input type="text" name="address" class="input-feild" value="<?php echo $address;?>"  required/></td>
								</div>
							</tr>
							<tr>
								<div class="grp-form">
									<td>Payment Type:</td>
									<td>
										<select name="pmnt" id="" class="input-feild">
											<option value="default">Payment Type</option>
											<option value="weekly">Weekly</option>
											<option value="daily">Daily</option>
											<option value="monthly">Monthly</option>
										</select>
									</td>
								</div>
							</tr>
						</table>
					</div>
				</div>
				<div class="col-md-6">
					<div class="refer-box">
						<table class="table table-reponsive">
							<tr>
								<div class="grp-form">
									<td>Date:</td>
									<td><input type="text" name="date" class="input-feild" value="<?php echo date("d-m-y");?>" /></td>
								</div>
							</tr>
							<tr>
								<div class="grp-form">
									<td>Refference Name:</td>
									<td><input type="text" name="ref" class="input-feild" value="<?php echo $reference;?>" required/></td>
								</div>
							</tr>
						</table>
					</div>
				</div>
			</div>
		</div>
</section>
<section class="account-section-2">
	<div class="container">
		<div class="mrfood-report-box">
			<table class="table table-reponsive report-table">
				<tr>
					<th>Box Type</th>
					<th>Price</th>
					<th>NO. of Order</th>
					<th>Discount</th>
					<th>Gross Total</th>
					<th>Paid</th>
					<th>Due</th>
					<th>Ref. Taka</th>
					<th>Paid</th>
					<th>Due</th>
					<th>Net Total</th>
					<th>Pmnt. Date</th>
					<th>Remarks</th>
				</tr>
				<tr>
					<td>
						<select name="boxtype"  class="food-field">
							<option value="default">select</option>
							<option value="executive">Executive</option>
							<option value="premium">Premium</option>
							<option value="exclusive">Exclusive</option>
						</select>
					</td>
					<td>
						<select name="price"  class="food-field" >
							<option value="default">select</option>
							<option <?php if(isset($price) && $price=="65") {?> selected="selected"<?php } ?> value="65" >65 TK</option>
							<option <?php if(isset($price) && $price=="85") {?> selected="selected"<?php } ?> value="85" >85 TK</option>
							<option <?php if(isset($price) && $price=="100") {?> selected="selected"<?php } ?> value="85" >100 TK</option>
						</select>
					</td>
					<td><input type="text" name="qnty" class="food-field" value="<?php echo $qnty;?>" required/></td>
					<td><input type="text" name="discount" value="<?php echo $discount;?>" class="food-field"/></td>
					<td><input type="text" class="food-field disabled" name="gross" value="<?php echo $gross;?>"/></td>
					<td><input type="text" name="paid"  value="<?php echo $paid;?>" class="food-field"/></td>
					<td><input type="text" name="due"  class="food-field" value="<?php echo $due;?>"/></td>
					<td><input type="text" name="ref_taka"  value="<?php echo $ref_taka;?>" class="food-field" /></td>
					<td><input type="text" name="ref_paid"  value="<?php echo $ref_paid;?>"class="food-field" /></td>
					<td><input type="text" name="ref_due" class="food-field disabled" value="<?php echo $ref_due;?>"/></td>
					<td><input type="text" class="food-field disabled" value="<?php echo $net;?>"/></td>
					<td><input type="text" id="indatepicker" value="<?php echo $pmnt_date;?>" name="pmnt_date" class="food-field"/></td>
					<td><input type="submit" name="save" class="add-btn"
								<?php 
									if(isset($_GET['ide'])){
											echo"value='Update'";
									}else{
										echo"value='Add'";
									}
								?>/>
					</td>
				</tr>
			</form>
			<?php
				$search ="SELECT * FROM `adminreport` ORDER BY `p_id` DESC LIMIT 25";
				$search_record = mysqli_query($conn, $search);
				while($row = mysqli_fetch_array($search_record)){
					$boxtype		=	$row['box_type'];
					$price			=	$row['price'];
					$qnty			=	$row['qnty'];
					$discount		=	$row['discount'];
					$gross			=	$row['gross_total'];
					$paid			=	$row['paid'];
					$due			=	$row['due'];
					$ref_taka		=	$row['ref_taka'];
					$ref_paid		=	$row['ref_paid'];
					$ref_due		=	$row['ref_due'];
					$net			=	$row['net_total'];
					$pmnt_date		=	$row['pmnt_date'];
					$remarks		=	$row['remarks'];
					?>
					<tr>
						<td align="center"><?php echo $boxtype;?></td>
						<td align="center"><?php echo $price;?></td>
						<td align="center"><?php echo $qnty;?></td>
						<td align="center"><?php echo $discount;?></td>
						<td align="center"><?php echo $gross;?></td>
						<td align="center"><?php echo $paid;?></td>
						<td align="center"><?php echo $due;?></td>
						<td align="center"><?php echo $ref_taka;?></td>
						<td align="center"><?php echo $ref_paid;?></td>
						<td align="center"><?php echo $ref_due;?></td>
						<td align="center"><?php echo $net;?></td>
						<td align="center"><?php echo $pmnt_date;?></td>
						<td align="center"><?php echo $remarks;?></td>
					</tr>
				<?php
				}
				mysqli_close($conn);
				?>
			</table>
		</div>
	</div>
</section>
<?php
}else{
	echo "<script>window.open('login.php','_self')</script>";
}
	include_once('include/footer.php');
?>