<?php 
	include_once('include/conn.php');
	include_once('include/functions.php');
	session_start();
	if(isset($_SESSION['username'])){
		if(isset($_GET['ide'])){
		//$delid = $_GET['idd'];
		$sql = "DELETE FROM `adminreport` WHERE p_id='".$_GET['ide']."'";
		$sql = mysqli_query($conn, $sql);
		if($sql){
			echo "<script>window.open('view.php?deleted=user has been deleted','_self')</script>";
		}else{
			echo mysqli_error($conn);
		}
	}
}
?>